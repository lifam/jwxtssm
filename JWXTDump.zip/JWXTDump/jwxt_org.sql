-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: jwxt
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `org` (
  `org_id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `info` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`org_id`),
  KEY `college_id` (`college_id`),
  CONSTRAINT `org_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `college` (`college_id`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org`
--

LOCK TABLES `org` WRITE;
/*!40000 ALTER TABLE `org` DISABLE KEYS */;
INSERT INTO `org` VALUES (1,1,'defaultName','defaultInfo'),(2,1,'机构AA','defaultInfo'),(3,1,'机构AB','defaultInfo'),(4,1,'机构AC','defaultInfo'),(5,1,'机构AD','defaultInfo'),(6,1,'机构AE','defaultInfo'),(7,1,'机构AF','defaultInfo'),(8,1,'机构AG','defaultInfo'),(9,1,'机构AH','defaultInfo'),(10,1,'机构AI','defaultInfo'),(11,1,'机构AJ','defaultInfo'),(12,1,'机构AK','defaultInfo'),(13,1,'机构AL','defaultInfo'),(14,1,'机构AM','defaultInfo'),(15,1,'机构AN','defaultInfo'),(16,1,'机构AO','defaultInfo'),(17,2,'机构BA','defaultInfo'),(18,2,'机构BB','defaultInfo'),(19,2,'机构BC','defaultInfo'),(20,2,'机构BD','defaultInfo'),(21,2,'机构BE','defaultInfo'),(22,2,'机构BF','defaultInfo'),(23,2,'机构BG','defaultInfo'),(24,2,'机构BH','defaultInfo'),(25,2,'机构BI','defaultInfo'),(26,2,'机构BJ','defaultInfo'),(27,2,'机构BK','defaultInfo'),(28,2,'机构BL','defaultInfo'),(29,2,'机构BM','defaultInfo'),(30,2,'机构BN','defaultInfo'),(31,2,'机构BO','defaultInfo'),(32,3,'机构CA','defaultInfo'),(33,3,'机构CB','defaultInfo'),(34,3,'机构CC','defaultInfo'),(35,3,'机构CD','defaultInfo'),(36,3,'机构CE','defaultInfo'),(37,3,'机构CF','defaultInfo'),(38,3,'机构CG','defaultInfo'),(39,3,'机构CH','defaultInfo'),(40,3,'机构CI','defaultInfo'),(41,3,'机构CJ','defaultInfo'),(42,3,'机构CK','defaultInfo'),(43,3,'机构CL','defaultInfo'),(44,3,'机构CM','defaultInfo'),(45,3,'机构CN','defaultInfo'),(46,3,'机构CO','defaultInfo'),(47,4,'机构DA','defaultInfo'),(48,4,'机构DB','defaultInfo'),(49,4,'机构DC','defaultInfo'),(50,4,'机构DD','defaultInfo'),(51,4,'机构DE','defaultInfo'),(52,4,'机构DF','defaultInfo'),(53,4,'机构DG','defaultInfo'),(54,4,'机构DH','defaultInfo'),(55,4,'机构DI','defaultInfo'),(56,4,'机构DJ','defaultInfo'),(57,4,'机构DK','defaultInfo'),(58,4,'机构DL','defaultInfo'),(59,4,'机构DM','defaultInfo'),(60,4,'机构DN','defaultInfo'),(61,4,'机构DO','defaultInfo'),(62,5,'机构EA','defaultInfo'),(63,5,'机构EB','defaultInfo'),(64,5,'机构EC','defaultInfo'),(65,5,'机构ED','defaultInfo'),(66,5,'机构EE','defaultInfo'),(67,5,'机构EF','defaultInfo'),(68,5,'机构EG','defaultInfo'),(69,5,'机构EH','defaultInfo'),(70,5,'机构EI','defaultInfo'),(71,5,'机构EJ','defaultInfo'),(72,5,'机构EK','defaultInfo'),(73,5,'机构EL','defaultInfo'),(74,5,'机构EM','defaultInfo'),(75,5,'机构EN','defaultInfo'),(76,5,'机构EO','defaultInfo'),(77,6,'机构FA','defaultInfo'),(78,6,'机构FB','defaultInfo'),(79,6,'机构FC','defaultInfo'),(80,6,'机构FD','defaultInfo'),(81,6,'机构FE','defaultInfo'),(82,6,'机构FF','defaultInfo'),(83,6,'机构FG','defaultInfo'),(84,6,'机构FH','defaultInfo'),(85,6,'机构FI','defaultInfo'),(86,6,'机构FJ','defaultInfo'),(87,6,'机构FK','defaultInfo'),(88,6,'机构FL','defaultInfo'),(89,6,'机构FM','defaultInfo'),(90,6,'机构FN','defaultInfo'),(91,6,'机构FO','defaultInfo'),(92,7,'机构GA','defaultInfo'),(93,7,'机构GB','defaultInfo'),(94,7,'机构GC','defaultInfo'),(95,7,'机构GD','defaultInfo'),(96,7,'机构GE','defaultInfo'),(97,7,'机构GF','defaultInfo'),(98,7,'机构GG','defaultInfo'),(99,7,'机构GH','defaultInfo'),(100,7,'机构GI','defaultInfo'),(101,7,'机构GJ','defaultInfo'),(102,7,'机构GK','defaultInfo'),(103,7,'机构GL','defaultInfo'),(104,7,'机构GM','defaultInfo'),(105,7,'机构GN','defaultInfo'),(106,7,'机构GO','defaultInfo'),(107,8,'机构HA','defaultInfo'),(108,8,'机构HB','defaultInfo'),(109,8,'机构HC','defaultInfo'),(110,8,'机构HD','defaultInfo'),(111,8,'机构HE','defaultInfo'),(112,8,'机构HF','defaultInfo'),(113,8,'机构HG','defaultInfo'),(114,8,'机构HH','defaultInfo'),(115,8,'机构HI','defaultInfo'),(116,8,'机构HJ','defaultInfo'),(117,8,'机构HK','defaultInfo'),(118,8,'机构HL','defaultInfo'),(119,8,'机构HM','defaultInfo'),(120,8,'机构HN','defaultInfo'),(121,8,'机构HO','defaultInfo'),(122,9,'机构IA','defaultInfo'),(123,9,'机构IB','defaultInfo'),(124,9,'机构IC','defaultInfo'),(125,9,'机构ID','defaultInfo'),(126,9,'机构IE','defaultInfo'),(127,9,'机构IF','defaultInfo'),(128,9,'机构IG','defaultInfo'),(129,9,'机构IH','defaultInfo'),(130,9,'机构II','defaultInfo'),(131,9,'机构IJ','defaultInfo'),(132,9,'机构IK','defaultInfo'),(133,9,'机构IL','defaultInfo'),(134,9,'机构IM','defaultInfo'),(135,9,'机构IN','defaultInfo'),(136,9,'机构IO','defaultInfo'),(137,10,'机构JA','defaultInfo'),(138,10,'机构JB','defaultInfo'),(139,10,'机构JC','defaultInfo'),(140,10,'机构JD','defaultInfo'),(141,10,'机构JE','defaultInfo'),(142,10,'机构JF','defaultInfo'),(143,10,'机构JG','defaultInfo'),(144,10,'机构JH','defaultInfo'),(145,10,'机构JI','defaultInfo'),(146,10,'机构JJ','defaultInfo'),(147,10,'机构JK','defaultInfo'),(148,10,'机构JL','defaultInfo'),(149,10,'机构JM','defaultInfo'),(150,10,'机构JN','defaultInfo'),(151,10,'机构JO','defaultInfo'),(152,11,'机构KA','defaultInfo'),(153,11,'机构KB','defaultInfo'),(154,11,'机构KC','defaultInfo'),(155,11,'机构KD','defaultInfo'),(156,11,'机构KE','defaultInfo'),(157,11,'机构KF','defaultInfo'),(158,11,'机构KG','defaultInfo'),(159,11,'机构KH','defaultInfo'),(160,11,'机构KI','defaultInfo'),(161,11,'机构KJ','defaultInfo'),(162,11,'机构KK','defaultInfo'),(163,11,'机构KL','defaultInfo'),(164,11,'机构KM','defaultInfo'),(165,11,'机构KN','defaultInfo'),(166,11,'机构KO','defaultInfo'),(167,12,'机构LA','defaultInfo'),(168,12,'机构LB','defaultInfo'),(169,12,'机构LC','defaultInfo'),(170,12,'机构LD','defaultInfo'),(171,12,'机构LE','defaultInfo'),(172,12,'机构LF','defaultInfo'),(173,12,'机构LG','defaultInfo'),(174,12,'机构LH','defaultInfo'),(175,12,'机构LI','defaultInfo'),(176,12,'机构LJ','defaultInfo'),(177,12,'机构LK','defaultInfo'),(178,12,'机构LL','defaultInfo'),(179,12,'机构LM','defaultInfo'),(180,12,'机构LN','defaultInfo'),(181,12,'机构LO','defaultInfo'),(182,13,'机构MA','defaultInfo'),(183,13,'机构MB','defaultInfo'),(184,13,'机构MC','defaultInfo'),(185,13,'机构MD','defaultInfo'),(186,13,'机构ME','defaultInfo'),(187,13,'机构MF','defaultInfo'),(188,13,'机构MG','defaultInfo'),(189,13,'机构MH','defaultInfo'),(190,13,'机构MI','defaultInfo'),(191,13,'机构MJ','defaultInfo'),(192,13,'机构MK','defaultInfo'),(193,13,'机构ML','defaultInfo'),(194,13,'机构MM','defaultInfo'),(195,13,'机构MN','defaultInfo'),(196,13,'机构MO','defaultInfo'),(197,14,'机构NA','defaultInfo'),(198,14,'机构NB','defaultInfo'),(199,14,'机构NC','defaultInfo'),(200,14,'机构ND','defaultInfo'),(201,14,'机构NE','defaultInfo'),(202,14,'机构NF','defaultInfo'),(203,14,'机构NG','defaultInfo'),(204,14,'机构NH','defaultInfo'),(205,14,'机构NI','defaultInfo'),(206,14,'机构NJ','defaultInfo'),(207,14,'机构NK','defaultInfo'),(208,14,'机构NL','defaultInfo'),(209,14,'机构NM','defaultInfo'),(210,14,'机构NN','defaultInfo'),(211,14,'机构NO','defaultInfo'),(212,15,'机构OA','defaultInfo'),(213,15,'机构OB','defaultInfo'),(214,15,'机构OC','defaultInfo'),(215,15,'机构OD','defaultInfo'),(216,15,'机构OE','defaultInfo'),(217,15,'机构OF','defaultInfo'),(218,15,'机构OG','defaultInfo'),(219,15,'机构OH','defaultInfo'),(220,15,'机构OI','defaultInfo'),(221,15,'机构OJ','defaultInfo'),(222,15,'机构OK','defaultInfo'),(223,15,'机构OL','defaultInfo'),(224,15,'机构OM','defaultInfo'),(225,15,'机构ON','defaultInfo'),(226,15,'机构OO','defaultInfo'),(227,16,'机构PA','defaultInfo'),(228,16,'机构PB','defaultInfo'),(229,16,'机构PC','defaultInfo'),(230,16,'机构PD','defaultInfo'),(231,16,'机构PE','defaultInfo'),(232,16,'机构PF','defaultInfo'),(233,16,'机构PG','defaultInfo'),(234,16,'机构PH','defaultInfo'),(235,16,'机构PI','defaultInfo'),(236,16,'机构PJ','defaultInfo'),(237,16,'机构PK','defaultInfo'),(238,16,'机构PL','defaultInfo'),(239,16,'机构PM','defaultInfo'),(240,16,'机构PN','defaultInfo'),(241,16,'机构PO','defaultInfo'),(242,17,'机构QA','defaultInfo'),(243,17,'机构QB','defaultInfo'),(244,17,'机构QC','defaultInfo'),(245,17,'机构QD','defaultInfo'),(246,17,'机构QE','defaultInfo'),(247,17,'机构QF','defaultInfo'),(248,17,'机构QG','defaultInfo'),(249,17,'机构QH','defaultInfo'),(250,17,'机构QI','defaultInfo'),(251,17,'机构QJ','defaultInfo'),(252,17,'机构QK','defaultInfo'),(253,17,'机构QL','defaultInfo'),(254,17,'机构QM','defaultInfo'),(255,17,'机构QN','defaultInfo'),(256,17,'机构QO','defaultInfo'),(257,18,'机构RA','defaultInfo'),(258,18,'机构RB','defaultInfo'),(259,18,'机构RC','defaultInfo'),(260,18,'机构RD','defaultInfo'),(261,18,'机构RE','defaultInfo'),(262,18,'机构RF','defaultInfo'),(263,18,'机构RG','defaultInfo'),(264,18,'机构RH','defaultInfo'),(265,18,'机构RI','defaultInfo'),(266,18,'机构RJ','defaultInfo'),(267,18,'机构RK','defaultInfo'),(268,18,'机构RL','defaultInfo'),(269,18,'机构RM','defaultInfo'),(270,18,'机构RN','defaultInfo'),(271,18,'机构RO','defaultInfo'),(272,19,'机构SA','defaultInfo'),(273,19,'机构SB','defaultInfo'),(274,19,'机构SC','defaultInfo'),(275,19,'机构SD','defaultInfo'),(276,19,'机构SE','defaultInfo'),(277,19,'机构SF','defaultInfo'),(278,19,'机构SG','defaultInfo'),(279,19,'机构SH','defaultInfo'),(280,19,'机构SI','defaultInfo'),(281,19,'机构SJ','defaultInfo'),(282,19,'机构SK','defaultInfo'),(283,19,'机构SL','defaultInfo'),(284,19,'机构SM','defaultInfo'),(285,19,'机构SN','defaultInfo'),(286,19,'机构SO','defaultInfo'),(287,20,'机构TA','defaultInfo'),(288,20,'机构TB','defaultInfo'),(289,20,'机构TC','defaultInfo'),(290,20,'机构TD','defaultInfo'),(291,20,'机构TE','defaultInfo'),(292,20,'机构TF','defaultInfo'),(293,20,'机构TG','defaultInfo'),(294,20,'机构TH','defaultInfo'),(295,20,'机构TI','defaultInfo'),(296,20,'机构TJ','defaultInfo'),(297,20,'机构TK','defaultInfo'),(298,20,'机构TL','defaultInfo'),(299,20,'机构TM','defaultInfo'),(300,20,'机构TN','defaultInfo'),(301,20,'机构TO','defaultInfo');
/*!40000 ALTER TABLE `org` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-12 20:36:39
